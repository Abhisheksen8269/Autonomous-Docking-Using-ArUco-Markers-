from launch import LaunchDescription
from launch_ros.actions import Node
import os
from ament_index_python.packages import get_package_share_directory

def generate_launch_description():

    # 1. Define the Obstacle Avoider Node (using the code from the previous step)
    # This node subscribes to /scan and publishes to /cmd_vel (or a remapped topic).
    # Assuming the executable name is 'avoider' based on our previous file 'avoidance_node.py'
    # If you named the executable differently in setup.py, use that name.
    avoider_node = Node(
        package="my_robot_control",
        executable="gazebo_move",  # Ensure this matches the entry_point in setup.py
        name="gazebo_move",
        output="screen",
        # We assume '/scan' is the Lidar topic and the node publishes to '/cmd_vel'.
    )

    # 2. Define the Gazebo Move Node (Your current structure)
    # Note: This node should NOT be run simultaneously with the avoider_node
    # if both publish to the same /cmd_vel topic, as they will fight each other.
    # We include it here as an example, but typically only ONE control node is active.
    gazebo_move_node = Node(
        package="my_robot_control",
        executable="scan_suscriber",  # This is the name from your entry points
        name="scan_suscriber",
        output="screen"
    )
    
    # 3. Define the Launch Description to start the nodes
    return LaunchDescription([
        # Launch the Obstacle Avoider Node. 
        # This is the core navigation logic you requested.
        avoider_node, 

        # Note on gazebo_move_node: You usually only launch ONE node that controls
        # velocity. If 'avoider_node' controls velocity based on Lidar, 
        # 'gazebo_move_node' should be disabled or repurposed. 
        # Launching both to /cmd_vel will cause unstable robot behavior.
        # gazebo_move_node, 
    ])
